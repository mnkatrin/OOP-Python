import os

from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QPixmap, QColor
from PyQt6.QtWidgets import QWidget, QLabel, QHBoxLayout, QVBoxLayout, QSizePolicy, QListWidgetItem


_APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class ProductWidget(QWidget):
    def __init__(self, data: dict, thumb_size: int = 80, bg_color: str = None):
        super().__init__()
        self.product_id = data['id']
        discount = int(data['discount'] or 0)
        quantity = int(data['quantity'] or 0)

        if bg_color:
            self.setStyleSheet(f'QWidget {{ background-color: {bg_color}; }}')
            palette = self.palette()
            palette.setColor(self.backgroundRole(), QColor(bg_color))
            self.setPalette(palette)

        h = QHBoxLayout(self)

        pix_label = QLabel()
        pix_label.setFixedSize(QSize(thumb_size, thumb_size))
        pix_label.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)

        pix = QPixmap()
        if data.get('image'):
            img_path = os.path.join(_APP_DIR, str(data['image']))
            pix = QPixmap(img_path)
        if pix.isNull():
            pix = QPixmap(os.path.join(_APP_DIR, 'picture.png'))
        if not pix.isNull():
            pix_label.setPixmap(pix.scaled(
                thumb_size, thumb_size,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation))
        h.addWidget(pix_label)

        v = QVBoxLayout()
        v.addWidget(QLabel(f"{data['category_name']} | {data['product_name']}"))
        desc = QLabel('Описание: ' + str(data['description'] or ''))
        desc.setWordWrap(True)
        v.addWidget(desc)
        v.addWidget(QLabel('Производитель: ' + str(data['manufacturer_name'])))
        v.addWidget(QLabel('Поставщик: ' + str(data['vendor_name'])))

        price_row = QHBoxLayout()
        price_label = QLabel('Цена: ' + str(data['price']) + ' руб.')
        if discount > 0:
            price_label.setStyleSheet('text-decoration: line-through; color: red;')
            final = float(data['price']) * (1 - discount / 100)
            price_row.addWidget(price_label)
            price_row.addWidget(QLabel(f'{final:.2f} руб.'))
        else:
            price_row.addWidget(price_label)
        price_row.addStretch()
        v.addLayout(price_row)
        v.addWidget(QLabel('Размер: ' + str(data['size'])))
        v.addWidget(QLabel('Количество на складе: ' + str(quantity)))
        h.addLayout(v)
        h.addWidget(QLabel(f'{discount}%'))


def fill_products(list_widget, products):
    list_widget.clear()
    for product in products:
        discount = int(product['discount'] or 0)
        quantity = int(product['quantity'] or 0)


        if quantity == 0:
            bg_color = '#ADD8E6'
        elif discount >= 15:
            bg_color = '#2E8B57'
        else:
            bg_color = None

        widget = ProductWidget(product, bg_color=bg_color)
        item = QListWidgetItem()
        item.setSizeHint(widget.sizeHint())
        if bg_color:
            item.setBackground(QColor(bg_color))
        list_widget.addItem(item)
        list_widget.setItemWidget(item, widget)
