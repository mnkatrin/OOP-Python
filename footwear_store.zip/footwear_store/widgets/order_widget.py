from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QWidget, QLabel, QHBoxLayout, QVBoxLayout


class OrderWidget(QWidget):
    def __init__(self, data: dict):
        super().__init__()
        self.order_id = data['id']

        h = QHBoxLayout(self)

        v = QVBoxLayout()
        v.addWidget(QLabel(f"<b>Артикул заказа: {data['code'] or '—'}</b>"))
        v.addWidget(QLabel(f"Статус заказа: {data['status_name'] or '—'}"))

        if data.get('pickup_city') and data.get('pickup_address'):
            pickup = f"{data['pickup_city']}, {data['pickup_address']}"
        elif data.get('pickup_address'):
            pickup = data['pickup_address']
        else:
            pickup = '—'
        v.addWidget(QLabel(f"Адрес пункта выдачи: {pickup}"))

        order_date = data['order_date'].strftime('%d.%m.%Y') if data.get('order_date') else '—'
        v.addWidget(QLabel(f"Дата заказа: {order_date}"))
        h.addLayout(v)
        h.addStretch()

        delivery_date = data['delivery_date'].strftime('%d.%m.%Y') if data.get('delivery_date') else '—'
        lbl = QLabel(f"Дата доставки:\n{delivery_date}")
        lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lbl.setStyleSheet('border: 1px solid gray; padding: 6px; min-width: 100px;')
        h.addWidget(lbl)
