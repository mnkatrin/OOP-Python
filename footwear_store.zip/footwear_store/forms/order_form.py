from PyQt6 import uic
from PyQt6.QtCore import Qt, QDate
from PyQt6.QtWidgets import QWidget

from database import get_connection
from utils import msg_error, msg_info


class OrderForm(QWidget):
    def __init__(self, parent_orders, order_id=None):
        super().__init__()
        uic.loadUi('ui/order_form.ui', self)
        self.parent_orders = parent_orders
        self.order_id = order_id

        self._load_statuses()

        if order_id is None:
            self.setWindowTitle('Добавить заказ')
            self.lb_form_title.setText('Добавление заказа')
            self.lb_id.hide()
            self.le_id.hide()
            today = QDate.currentDate()
            self.de_order_date.setDate(today)
            self.de_delivery_date.setDate(today.addDays(7))
        else:
            self.setWindowTitle(f'Редактировать заказ  (ID: {order_id})')
            self.lb_form_title.setText(f'Редактирование заказа (ID: {order_id})')
            self._load_order(order_id)

        self.le_id.setReadOnly(True)
        self.pb_save.clicked.connect(self._save)
        self.pb_cancel.clicked.connect(self.close)
        self.setWindowModality(Qt.WindowModality.ApplicationModal)

    def _load_statuses(self):
        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute('SELECT id, status_name FROM order_statuses ORDER BY id')
            for row in cur.fetchall():
                self.cb_status.addItem(row['status_name'], row['id'])
            conn.close()
        except Exception as e:
            msg_error(self, f'Не удалось загрузить статусы:\n{e}')

    def _load_order(self, order_id):
        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute('''
                SELECT o.*, pp.address AS pickup_address, pp.city AS pickup_city
                FROM orders o
                LEFT JOIN pickup_points pp ON o.pickup_point_id = pp.id
                WHERE o.id = %s
            ''', (order_id,))
            o = cur.fetchone()
            conn.close()
        except Exception as e:
            msg_error(self, f'Не удалось загрузить данные заказа:\n{e}')
            self.close()
            return

        if not o:
            msg_error(self, f'Заказ ID={order_id} не найден. Возможно, он был удалён.')
            self.close()
            return

        self.le_id.setText(str(o['id']))
        self.le_code.setText(str(o['code'] or ''))

        if o.get('pickup_city') and o.get('pickup_address'):
            self.le_pickup.setText(f"{o['pickup_city']}, {o['pickup_address']}")
        elif o.get('pickup_address'):
            self.le_pickup.setText(str(o['pickup_address']))

        if o.get('order_date'):
            self.de_order_date.setDate(QDate(
                o['order_date'].year, o['order_date'].month, o['order_date'].day))
        if o.get('delivery_date'):
            self.de_delivery_date.setDate(QDate(
                o['delivery_date'].year, o['delivery_date'].month, o['delivery_date'].day))

        idx = self.cb_status.findData(o['status_id'])
        if idx >= 0:
            self.cb_status.setCurrentIndex(idx)

    def _save(self):
        code = self.le_code.text().strip()
        if not code:
            msg_error(self, 'Поле «Артикул заказа» обязательно.\n'
                            'Введите артикул и повторите попытку.')
            self.le_code.setFocus()
            return

        if self.de_delivery_date.date() < self.de_order_date.date():
            msg_error(self, 'Дата выдачи не может быть раньше даты заказа.\n'
                            'Исправьте даты и повторите попытку.')
            return

        pickup_text   = self.le_pickup.text().strip()
        status_id     = self.cb_status.currentData()
        order_date    = self.de_order_date.date().toString('yyyy-MM-dd')
        delivery_date = self.de_delivery_date.date().toString('yyyy-MM-dd')

        try:
            conn = get_connection()
            cur = conn.cursor()
            pickup_point_id = None
            if pickup_text:
                cur.execute(
                    "SELECT id FROM pickup_points WHERE address=%s OR "
                    "CONCAT(city,', ',address)=%s LIMIT 1",
                    (pickup_text, pickup_text))
                row = cur.fetchone()
                if row:
                    pickup_point_id = row['id']
                else:
                    cur.execute('INSERT INTO pickup_points (address) VALUES (%s)', (pickup_text,))
                    pickup_point_id = cur.lastrowid

            if self.order_id is None:
                cur.execute('''
                    INSERT INTO orders (code, status_id, pickup_point_id, order_date, delivery_date)
                    VALUES (%s,%s,%s,%s,%s)
                ''', (code, status_id, pickup_point_id, order_date, delivery_date))
            else:
                cur.execute('''
                    UPDATE orders
                    SET code=%s, status_id=%s, pickup_point_id=%s,
                        order_date=%s, delivery_date=%s
                    WHERE id=%s
                ''', (code, status_id, pickup_point_id, order_date, delivery_date, self.order_id))

            conn.commit()
            conn.close()
        except Exception as e:
            msg_error(self, f'Не удалось сохранить заказ:\n{e}')
            return

        msg_info(self, 'Заказ успешно сохранён.')
        self.parent_orders.refresh_orders()
        self.close()
