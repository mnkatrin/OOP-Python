import os

from PyQt6 import uic
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPixmap
from PyQt6.QtWidgets import QWidget, QFileDialog

from database import get_connection
from utils import msg_error, msg_warning, msg_info

_APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class ProductForm(QWidget):
    def __init__(self, parent_admin, product_id=None):
        super().__init__()
        uic.loadUi('ui/product_form.ui', self)
        self.parent_admin = parent_admin
        self.product_id = product_id
        self._new_image_path = None
        self._old_image_path = None

        self._load_references()

        if product_id is None:
            self.setWindowTitle('Добавить товар')
            self.lb_form_title.setText('Добавление товара')
            self.lb_id.hide()
            self.le_id.hide()
            self._show_placeholder()
        else:
            self.setWindowTitle(f'Редактировать товар  (ID: {product_id})')
            self.lb_form_title.setText(f'Редактирование товара (ID: {product_id})')
            self._load_product(product_id)

        self.le_id.setReadOnly(True)
        self.pb_choose_photo.clicked.connect(self._choose_photo)
        self.pb_save.clicked.connect(self._save)
        self.pb_cancel.clicked.connect(self.close)
        from PyQt6.QtCore import Qt as QtCore
        self.setWindowModality(QtCore.WindowModality.ApplicationModal)

    def _load_references(self):
        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute('SELECT id, category_name FROM categories ORDER BY category_name')
            for row in cur.fetchall():
                self.cb_category.addItem(row['category_name'], row['id'])
            cur.execute('SELECT id, manufacturer_name FROM manufacturers ORDER BY manufacturer_name')
            for row in cur.fetchall():
                self.cb_manufacturer.addItem(row['manufacturer_name'], row['id'])
            cur.execute('SELECT id, vendor_name FROM vendors ORDER BY vendor_name')
            for row in cur.fetchall():
                self.cb_vendor.addItem(row['vendor_name'], row['id'])
            conn.close()
        except Exception as e:
            msg_error(self, f'Не удалось загрузить справочники:\n{e}')

    def _show_placeholder(self):
        pix = QPixmap(os.path.join(_APP_DIR, 'picture.png'))
        if not pix.isNull():
            self.lb_photo.setPixmap(pix.scaled(
                150, 100, Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation))

    def _load_product(self, product_id):
        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute('SELECT * FROM products WHERE id = %s', (product_id,))
            p = cur.fetchone()
            conn.close()
        except Exception as e:
            msg_error(self, f'Не удалось загрузить данные товара:\n{e}')
            self.close()
            return

        if not p:
            msg_error(self, f'Товар ID={product_id} не найден. Возможно, он был удалён.')
            self.close()
            return

        self.le_id.setText(str(p['id']))
        self.le_name.setText(str(p['product_name'] or ''))
        self.te_description.setPlainText(str(p['description'] or ''))
        self.le_size.setText(str(p['size'] or ''))
        self.dsb_price.setValue(float(p['price'] or 0))
        self.sb_quantity.setValue(int(p['quantity'] or 0))
        self.sb_discount.setValue(int(p['discount'] or 0))

        for combo, field in ((self.cb_category, 'category_id'),
                             (self.cb_manufacturer, 'manufacturer_id'),
                             (self.cb_vendor, 'vendor_id')):
            idx = combo.findData(p[field])
            if idx >= 0:
                combo.setCurrentIndex(idx)

        self._old_image_path = p.get('image')
        pix = QPixmap()
        if p.get('image'):
            pix = QPixmap(os.path.join(_APP_DIR, str(p['image'])))
        if pix.isNull():
            pix = QPixmap(os.path.join(_APP_DIR, 'picture.png'))
        if not pix.isNull():
            self.lb_photo.setPixmap(pix.scaled(
                150, 100, Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation))

    def _choose_photo(self):
        path, _ = QFileDialog.getOpenFileName(
            self, 'Выберите изображение', '',
            'Изображения (*.png *.jpg *.jpeg *.bmp)')
        if not path:
            return
        pix = QPixmap(path)
        if pix.isNull():
            msg_warning(self, 'Файл не является изображением.\n'
                              'Выберите файл в формате PNG, JPG или BMP.')
            return
        self._new_image_path = path
        self.lb_photo.setPixmap(pix.scaled(
            150, 100, Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation))

    def _save(self):
        name = self.le_name.text().strip()
        if not name:
            msg_error(self, 'Поле «Наименование» обязательно.\n'
                            'Введите название товара и повторите попытку.')
            self.le_name.setFocus()
            return

        price           = self.dsb_price.value()
        quantity        = self.sb_quantity.value()
        category_id     = self.cb_category.currentData()
        manufacturer_id = self.cb_manufacturer.currentData()
        vendor_id       = self.cb_vendor.currentData()
        description     = self.te_description.toPlainText().strip()
        size            = self.le_size.text().strip()
        discount        = self.sb_discount.value()
        image_path      = self._old_image_path

        if self._new_image_path:
            ext = os.path.splitext(self._new_image_path)[1].lower()
            dest_name = (f'product_{self.product_id}{ext}' if self.product_id
                         else f'product_tmp_{os.path.basename(self._new_image_path)}')
            dest_path = os.path.join(_APP_DIR, dest_name)
            pix = QPixmap(self._new_image_path)
            if not pix.scaled(300, 200, Qt.AspectRatioMode.KeepAspectRatio,
                               Qt.TransformationMode.SmoothTransformation).save(dest_path):
                msg_error(self, f'Не удалось сохранить изображение.\n'
                                f'Проверьте права доступа к папке проекта.')
                return
            if self._old_image_path:
                old_full = os.path.join(_APP_DIR, self._old_image_path)
                if os.path.exists(old_full) and old_full != dest_path:
                    try:
                        os.remove(old_full)
                    except OSError:
                        pass
            image_path = dest_name

        try:
            conn = get_connection()
            cur = conn.cursor()
            if self.product_id is None:
                cur.execute('SELECT COALESCE(MAX(id),0)+1 AS new_id FROM products')
                new_id = cur.fetchone()['new_id']
                cur.execute('''
                    INSERT INTO products
                        (id, product_name, category_id, description, manufacturer_id,
                         vendor_id, price, size, quantity, discount, image, article)
                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                ''', (new_id, name, category_id, description, manufacturer_id,
                      vendor_id, price, size, quantity, discount, image_path,
                      f'ART{new_id:04d}'))
                if self._new_image_path and image_path and 'product_tmp_' in image_path:
                    final_name = f'product_{new_id}{os.path.splitext(image_path)[1]}'
                    old_p = os.path.join(_APP_DIR, image_path)
                    new_p = os.path.join(_APP_DIR, final_name)
                    if os.path.exists(old_p):
                        os.rename(old_p, new_p)
                    cur.execute('UPDATE products SET image=%s WHERE id=%s', (final_name, new_id))
            else:
                cur.execute('''
                    UPDATE products
                    SET product_name=%s, category_id=%s, description=%s,
                        manufacturer_id=%s, vendor_id=%s, price=%s,
                        size=%s, quantity=%s, discount=%s, image=%s
                    WHERE id=%s
                ''', (name, category_id, description, manufacturer_id,
                      vendor_id, price, size, quantity, discount,
                      image_path, self.product_id))
            conn.commit()
            conn.close()
        except Exception as e:
            msg_error(self, f'Не удалось сохранить данные:\n{e}')
            return

        msg_info(self, 'Данные успешно сохранены.')
        self.parent_admin.refresh_products()
        self.close()
