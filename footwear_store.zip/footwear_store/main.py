import os
import sys
import traceback

from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import QApplication, QMessageBox

from windows.login import Login

_APP_DIR = os.path.dirname(os.path.abspath(__file__))


def exception_hook(extype, value, tb):
    traceback.print_exception(extype, value, tb)
    QMessageBox.critical(None, 'Непредвиденная ошибка',
                         f'Произошла ошибка приложения:\n{value}')


if __name__ == '__main__':
    app = QApplication(sys.argv)

    for name in ('icon.ico', 'icon.png'):
        icon_path = os.path.join(_APP_DIR, name)
        icon = QIcon(icon_path)
        if not icon.isNull():
            app.setWindowIcon(icon)
            break

    sys.excepthook = exception_hook
    window = Login()
    window.show()
    sys.exit(app.exec())
