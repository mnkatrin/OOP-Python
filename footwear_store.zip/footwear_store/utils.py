from PyQt6.QtWidgets import QMessageBox


def msg_error(parent, text: str):
    QMessageBox.critical(parent, 'Ошибка', text)


def msg_warning(parent, text: str):
    QMessageBox.warning(parent, 'Предупреждение', text)


def msg_info(parent, text: str):
    QMessageBox.information(parent, 'Информация', text)


def msg_confirm(parent, text: str) -> bool:
    return QMessageBox.question(
        parent, 'Подтверждение действия', text,
        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
    ) == QMessageBox.StandardButton.Yes
