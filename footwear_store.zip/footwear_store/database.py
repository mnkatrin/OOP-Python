import pymysql


def get_connection():
    return pymysql.connect(
        host='localhost', user='root', password='',
        database='footwear_store',
        cursorclass=pymysql.cursors.DictCursor
    )


def fetch_products():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute('''
        SELECT p.id, p.article, p.product_name, p.size, p.price,
               p.discount, p.quantity, p.description, p.image,
               v.vendor_name, m.manufacturer_name, c.category_name
        FROM products p
        JOIN vendors v ON p.vendor_id = v.id
        JOIN manufacturers m ON p.manufacturer_id = m.id
        JOIN categories c ON p.category_id = c.id
    ''')
    products = cur.fetchall()
    conn.close()
    return products


def fetch_orders():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute('''
        SELECT o.id, o.code, o.order_date, o.delivery_date,
               s.status_name,
               pp.address AS pickup_address,
               pp.city    AS pickup_city,
               o.pickup_point_id
        FROM orders o
        LEFT JOIN order_statuses s  ON o.status_id = s.id
        LEFT JOIN pickup_points pp  ON o.pickup_point_id = pp.id
        ORDER BY o.id DESC
    ''')
    orders = cur.fetchall()
    conn.close()
    return orders
