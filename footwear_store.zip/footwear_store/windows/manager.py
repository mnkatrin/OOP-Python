from PyQt6 import uic
from PyQt6.QtWidgets import QMainWindow

from utils import msg_error
from windows.search_mixin import SearchFilterMixin


class Manager(SearchFilterMixin, QMainWindow):
    def __init__(self, user: dict, login_window):
        super().__init__()
        uic.loadUi('ui/manager.ui', self)
        fio = f"{user['last_name']} {user['first_name']} {user['middle_name']}"
        self.setWindowTitle(f'Список товаров — Менеджер ({fio})')
        self.lb_title.setText('Список товаров — Менеджер')
        self.lb_fio.setText(fio)
        self.login_window = login_window
        self.pb_exit.clicked.connect(self._go_back)
        self.pb_orders.clicked.connect(self._open_orders)
        try:
            self.init_search_filter()
        except Exception as e:
            msg_error(self, f'Не удалось загрузить данные:\n{e}')

    def _open_orders(self):
        from windows.orders import Orders
        self.orders_window = Orders(self, is_admin=False)
        self.orders_window.show()
        self.hide()

    def _go_back(self):
        self.login_window.show()
        self.close()
