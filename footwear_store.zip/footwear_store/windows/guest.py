from PyQt6 import uic
from PyQt6.QtWidgets import QMainWindow

from database import fetch_products
from utils import msg_error
from widgets.product_widget import fill_products


class Guest(QMainWindow):
    def __init__(self, login_window):
        super().__init__()
        uic.loadUi('ui/guest.ui', self)
        self.setWindowTitle('Список товаров — Гость')
        self.login_window = login_window
        self.pb_exit.clicked.connect(self._go_back)
        try:
            fill_products(self.lw_products, fetch_products())
        except Exception as e:
            msg_error(self, f'Не удалось загрузить список товаров:\n{e}')

    def _go_back(self):
        self.login_window.show()
        self.close()
