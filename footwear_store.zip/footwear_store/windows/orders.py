from PyQt6 import uic
from PyQt6.QtWidgets import QMainWindow, QListWidgetItem

from database import get_connection, fetch_orders
from utils import msg_error, msg_warning, msg_info, msg_confirm
from widgets.order_widget import OrderWidget


def fill_orders(list_widget, orders):
    list_widget.clear()
    for order in orders:
        widget = OrderWidget(order)
        item = QListWidgetItem()
        item.setSizeHint(widget.sizeHint())
        list_widget.addItem(item)
        list_widget.setItemWidget(item, widget)


class Orders(QMainWindow):
    def __init__(self, parent_window, is_admin: bool = False):
        super().__init__()
        uic.loadUi('ui/orders.ui', self)
        self.setWindowTitle('Список заказов')
        self.parent_window = parent_window
        self.is_admin = is_admin
        self._edit_window = None

        self.pb_add.setVisible(is_admin)
        self.pb_delete.setVisible(is_admin)
        self.lb_hint.setVisible(is_admin)

        self.pb_back.clicked.connect(self._go_back)
        if is_admin:
            self.pb_add.clicked.connect(self._add_order)
            self.pb_delete.clicked.connect(self._delete_order)
            self.lw_orders.itemDoubleClicked.connect(self._edit_order)

        self.refresh_orders()

    def refresh_orders(self):
        try:
            fill_orders(self.lw_orders, fetch_orders())
        except Exception as e:
            msg_error(self, f'Не удалось загрузить список заказов:\n{e}')

    def _add_order(self):
        if self._edit_window and self._edit_window.isVisible():
            msg_warning(self, 'Уже открыто окно редактирования.\n'
                              'Закройте его перед добавлением нового заказа.')
            self._edit_window.activateWindow()
            return
        from forms.order_form import OrderForm
        self._edit_window = OrderForm(self, order_id=None)
        self._edit_window.show()

    def _edit_order(self, item):
        if self._edit_window and self._edit_window.isVisible():
            msg_warning(self, 'Уже открыто окно редактирования.\n'
                              'Закройте его перед редактированием другого заказа.')
            self._edit_window.activateWindow()
            return
        widget = self.lw_orders.itemWidget(item)
        if widget is None:
            return
        from forms.order_form import OrderForm
        self._edit_window = OrderForm(self, order_id=widget.order_id)
        self._edit_window.show()

    def _delete_order(self):
        item = self.lw_orders.currentItem()
        if item is None:
            msg_warning(self, 'Заказ не выбран.\n'
                              'Кликните по нужному заказу в списке и повторите.')
            return
        widget = self.lw_orders.itemWidget(item)
        if widget is None:
            return
        order_id = widget.order_id

        if not msg_confirm(self, f'Удалить заказ ID={order_id}?\nЭто действие необратимо.'):
            return

        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute('DELETE FROM order_items WHERE order_id=%s', (order_id,))
            cur.execute('DELETE FROM orders WHERE id=%s', (order_id,))
            conn.commit()
            conn.close()
        except Exception as e:
            msg_error(self, f'Не удалось удалить заказ:\n{e}')
            return

        msg_info(self, f'Заказ ID={order_id} успешно удалён.')
        self.refresh_orders()

    def _go_back(self):
        self.parent_window.show()
        self.close()
