from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import QListWidgetItem

from database import fetch_products
from widgets.product_widget import ProductWidget, fill_products


class SearchFilterMixin:
    SEARCH_FIELDS = [
        'product_name', 'description', 'manufacturer_name',
        'vendor_name', 'category_name', 'article', 'size'
    ]

    def init_search_filter(self):
        self._all_products = fetch_products()
        self.cb_vendor.addItem('Все поставщики')
        for v in sorted({p['vendor_name'] for p in self._all_products}):
            self.cb_vendor.addItem(v)
        self.cb_sort.addItem('Без сортировки')
        self.cb_sort.addItem('Количество ↑')
        self.cb_sort.addItem('Количество ↓')
        self.le_search.textChanged.connect(self.apply_filters)
        self.cb_vendor.currentIndexChanged.connect(self.apply_filters)
        self.cb_sort.currentIndexChanged.connect(self.apply_filters)
        self.pb_show_all.clicked.connect(self.show_all)
        self.apply_filters()

    def refresh_products(self):
        self._all_products = fetch_products()
        current = self.cb_vendor.currentText()
        self.cb_vendor.blockSignals(True)
        self.cb_vendor.clear()
        self.cb_vendor.addItem('Все поставщики')
        for v in sorted({p['vendor_name'] for p in self._all_products}):
            self.cb_vendor.addItem(v)
        idx = self.cb_vendor.findText(current)
        self.cb_vendor.setCurrentIndex(idx if idx >= 0 else 0)
        self.cb_vendor.blockSignals(False)
        self.apply_filters()

    def show_all(self):
        for w in (self.le_search, self.cb_vendor, self.cb_sort):
            w.blockSignals(True)
        self.le_search.clear()
        self.cb_vendor.setCurrentIndex(0)
        self.cb_sort.setCurrentIndex(0)
        for w in (self.le_search, self.cb_vendor, self.cb_sort):
            w.blockSignals(False)
        fill_products(self.lw_products, self._all_products)

    def apply_filters(self):
        search   = self.le_search.text().strip().lower()
        vendor   = self.cb_vendor.currentText()
        sort_idx = self.cb_sort.currentIndex()
        result   = self._all_products

        if vendor != 'Все поставщики':
            result = [p for p in result if p['vendor_name'] == vendor]
        if search:
            result = [p for p in result
                      if any(search in str(p.get(f) or '').lower()
                             for f in self.SEARCH_FIELDS)]
        if sort_idx == 1:
            result = sorted(result, key=lambda p: int(p['quantity'] or 0))
        elif sort_idx == 2:
            result = sorted(result, key=lambda p: int(p['quantity'] or 0), reverse=True)

        fill_products(self.lw_products, result)
