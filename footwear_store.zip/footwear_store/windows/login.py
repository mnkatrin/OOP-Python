import os

from PyQt6 import uic
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPixmap, QIcon
from PyQt6.QtWidgets import QWidget

from database import get_connection
from utils import msg_error

_APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class Login(QWidget):
    def __init__(self):
        super().__init__()
        uic.loadUi('ui/login.ui', self)
        self.setWindowTitle('Авторизация — Магазин обуви')

        for name in ('icon.ico', 'icon.png'):
            icon_path = os.path.join(_APP_DIR, name)
            icon = QIcon(icon_path)
            if not icon.isNull():
                self.setWindowIcon(icon)
                break

        self.pb_login.clicked.connect(self._login)
        self.pb_guest.clicked.connect(self._enter_as_guest)

    def showEvent(self, event):
        super().showEvent(event)
        self._load_logo()

    def _load_logo(self):
        logo_path = os.path.join(_APP_DIR, 'logo.png')
        pix = QPixmap(logo_path)
        if pix.isNull():
            return
        w = self.lb_logo.width() or 200
        h = self.lb_logo.height() or 90
        self.lb_logo.setPixmap(pix.scaled(
            w, h,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation))

    def _login(self):
        login    = self.le_login.text().strip()
        password = self.le_password.text()

        if not login:
            msg_error(self, 'Введите логин.')
            self.le_login.setFocus()
            return
        if not password:
            msg_error(self, 'Введите пароль.')
            self.le_password.setFocus()
            return

        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute('SELECT * FROM users WHERE login=%s AND password=%s', (login, password))
            user = cur.fetchone()
            conn.close()
        except Exception as e:
            msg_error(self, f'Не удалось подключиться к базе данных:\n{e}\n\n'
                            'Убедитесь, что сервер MySQL запущен.')
            return

        if not user:
            msg_error(self, 'Неверный логин или пароль.\nПроверьте данные и попробуйте снова.')
            self.le_password.clear()
            self.le_login.setFocus()
            return

        from windows.admin   import Admin
        from windows.manager import Manager
        from windows.client  import Client

        role_map = {
            'Администратор': lambda: Admin(user, self),
            'Менеджер':      lambda: Manager(user, self),
            'Клиент':        lambda: Client(user, self),
        }
        if user['role'] not in role_map:
            msg_error(self, f'Роль «{user["role"]}» не поддерживается.\n'
                            'Обратитесь к администратору.')
            return

        self.window = role_map[user['role']]()
        self.window.show()
        self.hide()
        self.le_password.clear()
        self.le_login.clear()

    def _enter_as_guest(self):
        from windows.guest import Guest
        self.window = Guest(self)
        self.window.show()
        self.hide()
