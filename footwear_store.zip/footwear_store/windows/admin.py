import os

from PyQt6 import uic
from PyQt6.QtWidgets import QMainWindow

from database import get_connection
from utils import msg_error, msg_warning, msg_info, msg_confirm
from windows.search_mixin import SearchFilterMixin

_APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class Admin(SearchFilterMixin, QMainWindow):
    def __init__(self, user: dict, login_window):
        super().__init__()
        uic.loadUi('ui/admin.ui', self)
        fio = f"{user['last_name']} {user['first_name']} {user['middle_name']}"
        self.setWindowTitle(f'Управление товарами — Администратор ({fio})')
        self.lb_title.setText('Управление товарами — Администратор')
        self.lb_fio.setText(fio)
        self.login_window = login_window
        self._edit_window = None

        self.pb_exit.clicked.connect(self._go_back)
        self.pb_add.clicked.connect(self._add_product)
        self.pb_delete.clicked.connect(self._delete_product)
        self.pb_orders.clicked.connect(self._open_orders)
        self.lw_products.itemDoubleClicked.connect(self._edit_product)

        try:
            self.init_search_filter()
        except Exception as e:
            msg_error(self, f'Не удалось загрузить данные:\n{e}')

    def _open_orders(self):
        from windows.orders import Orders
        self.orders_window = Orders(self, is_admin=True)
        self.orders_window.show()
        self.hide()

    def _add_product(self):
        if self._edit_window and self._edit_window.isVisible():
            msg_warning(self, 'Уже открыто окно редактирования.\n'
                              'Закройте его перед добавлением нового товара.')
            self._edit_window.activateWindow()
            return
        from forms.product_form import ProductForm
        self._edit_window = ProductForm(self, product_id=None)
        self._edit_window.show()

    def _edit_product(self, item):
        if self._edit_window and self._edit_window.isVisible():
            msg_warning(self, 'Уже открыто окно редактирования.\n'
                              'Закройте его перед редактированием другого товара.')
            self._edit_window.activateWindow()
            return
        widget = self.lw_products.itemWidget(item)
        if widget is None:
            return
        from forms.product_form import ProductForm
        self._edit_window = ProductForm(self, product_id=widget.product_id)
        self._edit_window.show()

    def _delete_product(self):
        item = self.lw_products.currentItem()
        if item is None:
            msg_warning(self, 'Товар не выбран.\n'
                              'Кликните по нужному товару в списке и повторите.')
            return
        widget = self.lw_products.itemWidget(item)
        if widget is None:
            return
        product_id = widget.product_id

        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute('SELECT COUNT(*) AS cnt FROM order_items WHERE product_id=%s',
                        (product_id,))
            cnt = cur.fetchone()['cnt']
        except Exception as e:
            msg_error(self, f'Ошибка при проверке заказов:\n{e}')
            return

        if cnt > 0:
            conn.close()
            msg_warning(self, f'Товар ID={product_id} входит в {cnt} заказ(а/ов) '
                              f'и не может быть удалён.\nСначала удалите связанные заказы.')
            return

        if not msg_confirm(self, f'Удалить товар ID={product_id}?\nЭто действие необратимо.'):
            conn.close()
            return

        try:
            cur.execute('SELECT image FROM products WHERE id=%s', (product_id,))
            image_path = (cur.fetchone() or {}).get('image')
            cur.execute('DELETE FROM products WHERE id=%s', (product_id,))
            conn.commit()
            conn.close()
        except Exception as e:
            msg_error(self, f'Не удалось удалить товар:\n{e}')
            return

        if image_path:
            full = os.path.join(_APP_DIR, image_path)
            if os.path.exists(full):
                try:
                    os.remove(full)
                except OSError:
                    pass

        msg_info(self, f'Товар ID={product_id} успешно удалён.')
        self.refresh_products()

    def _go_back(self):
        self.login_window.show()
        self.close()
