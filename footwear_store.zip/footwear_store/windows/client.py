from PyQt6 import uic
from PyQt6.QtWidgets import QMainWindow

from database import fetch_products
from utils import msg_error
from widgets.product_widget import fill_products


class Client(QMainWindow):
    def __init__(self, user: dict, login_window):
        super().__init__()
        uic.loadUi('ui/client.ui', self)
        fio = f"{user['last_name']} {user['first_name']} {user['middle_name']}"
        self.setWindowTitle(f'Список товаров — {fio}')
        self.lb_title.setText(f'Список товаров — Клиент')
        self.lb_fio.setText(fio)
        self.login_window = login_window
        self.pb_exit.clicked.connect(self._go_back)
        try:
            fill_products(self.lw_products, fetch_products())
        except Exception as e:
            msg_error(self, f'Не удалось загрузить список товаров:\n{e}')

    def _go_back(self):
        self.login_window.show()
        self.close()
